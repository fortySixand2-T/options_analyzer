"""Options opportunity scanner service."""
